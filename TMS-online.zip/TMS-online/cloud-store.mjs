import {Worker} from 'node:worker_threads';
// Preserve the existing synchronous SQLite transaction boundaries. Network I/O
// runs in a worker; this deliberately serializes queries for a small deployment.
export function cloudStore(url,authToken){
 const control=new Int32Array(new SharedArrayBuffer(8));
 const bytes=new Uint8Array(new SharedArrayBuffer(32*1024*1024));
 const worker=new Worker(new URL('./cloud-worker.mjs',import.meta.url),{workerData:{url,authToken,control,bytes}});
 worker.on('error',()=>{});worker.unref();let closed=false;
 function call(op,sql='',args=[]){
  if(closed)throw Error('Database connection is closed. Restart the server.');
  Atomics.store(control,0,0);worker.postMessage({op,sql,args});
  if(Atomics.wait(control,0,0,30000)==='timed-out'){closed=true;worker.terminate();throw Error('Database timeout. Operation outcome is uncertain; do not retry writes blindly.');}
  const result=JSON.parse(new TextDecoder().decode(bytes.subarray(0,Atomics.load(control,1))));
  if(result.error)throw Object.assign(Error('Database operation failed ('+result.error+').'),{code:result.error});
  return result.value;
 }
 return {exec:sql=>call('exec',sql),prepare:sql=>({all:(...args)=>call('query',sql,args).rows,get:(...args)=>call('query',sql,args).rows[0],run:(...args)=>{const r=call('query',sql,args);return {changes:r.rowsAffected,lastInsertRowid:r.lastInsertRowid};}}),close(){if(!closed){try{call('close');}finally{closed=true;worker.terminate();}}}};
}
