import {parentPort,workerData} from 'node:worker_threads';
const {control,bytes,url,authToken}=workerData;
let client,transaction,startError;
try{const {createClient}=await import('@libsql/client');client=createClient({url,authToken,intMode:'number'});}catch{startError='CONNECTION_INIT';}
parentPort.on('message',async({op,sql,args})=>{
 let result;
 try{
  if(startError)throw {code:startError};
  let value;
  if(op==='close'){if(transaction)await transaction.rollback();client.close();value=true;}
  else if(op==='exec'){
   const command=sql.trim().toUpperCase();
   if(command==='BEGIN'){if(transaction)throw {code:'TRANSACTION_ACTIVE'};transaction=await client.transaction('write');}
   else if(command==='COMMIT'||command==='ROLLBACK'){if(!transaction)throw {code:'NO_TRANSACTION'};const tx=transaction;transaction=null;try{await tx[command==='COMMIT'?'commit':'rollback']();}finally{tx.close();}}
   else await (transaction||client).executeMultiple(sql);
   value=true;
  }else{const r=await (transaction||client).execute({sql,args});value={rows:r.rows.map(row=>Object.fromEntries(r.columns.map(c=>[c,row[c]]))),rowsAffected:r.rowsAffected,lastInsertRowid:r.lastInsertRowid==null?null:String(r.lastInsertRowid)};}
  result={value};
 }catch(e){result={error:/^[A-Z0-9_]+$/.test(e.code||'')?e.code:'QUERY_FAILED'};}
 let encoded=new TextEncoder().encode(JSON.stringify(result));
 if(encoded.length>bytes.length)encoded=new TextEncoder().encode(JSON.stringify({error:'RESULT_TOO_LARGE'}));
 bytes.set(encoded);Atomics.store(control,1,encoded.length);Atomics.store(control,0,1);Atomics.notify(control,0);
});
