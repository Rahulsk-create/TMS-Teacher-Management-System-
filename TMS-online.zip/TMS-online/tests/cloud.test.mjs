import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {cloudStore} from '../cloud-store.mjs';
import {openStore,checkPassword} from '../store.mjs';
import {bootstrapAdmin} from '../bootstrap.mjs';
test('libSQL bridge preserves transactions, parameters and data across reconnection',()=>{
 const dir=mkdtempSync(join(tmpdir(),'tms-cloud-'));const url=pathToFileURL(join(dir,'test.db')).href;let db=cloudStore(url);
 try{
  db.exec('CREATE TABLE sample(id INTEGER PRIMARY KEY, value TEXT UNIQUE);');
  db.exec('BEGIN');db.prepare('INSERT INTO sample VALUES(?,?)').run(1,"quoted ' value");db.exec('ROLLBACK');
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM sample').get().n,0);
  db.exec('BEGIN');db.prepare('INSERT INTO sample VALUES(?,?)').run(2,'persisted');db.exec('COMMIT');
  assert.throws(()=>db.prepare('INSERT INTO sample VALUES(?,?)').run(3,'persisted'));
  db.close();db=cloudStore(url);assert.equal(db.prepare('SELECT value FROM sample WHERE id=?').get(2).value,'persisted');
  assert.equal(db.prepare('UPDATE sample SET value=? WHERE id=?').run('updated',2).changes,1);
 }finally{db.close();rmSync(dir,{recursive:true,force:true});}
});
test('initial administrator is created once and cannot be reset by bootstrap',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'tms-bootstrap-'));const db=openStore(dir);
 const old=process.env.INITIAL_ADMIN_PASSWORD;
 try{
  process.env.INITIAL_ADMIN_PASSWORD='test-only-bootstrap-password';await bootstrapAdmin(db);
  const user=db.prepare('SELECT * FROM users').get();assert.equal(user.username,'admin');assert.equal(user.must_change,1);assert.ok(await checkPassword(process.env.INITIAL_ADMIN_PASSWORD,user.password));
  process.env.INITIAL_ADMIN_PASSWORD='different-test-password';await bootstrapAdmin(db);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM users').get().n,1);assert.equal(db.prepare('SELECT password FROM users').get().password,user.password);
 }finally{if(old===undefined)delete process.env.INITIAL_ADMIN_PASSWORD;else process.env.INITIAL_ADMIN_PASSWORD=old;db.close();rmSync(dir,{recursive:true,force:true});}
});
