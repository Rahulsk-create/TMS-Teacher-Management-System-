import {hashPassword,userId,token,log} from './store.mjs';
export async function bootstrapAdmin(db){
 if(!process.env.INITIAL_ADMIN_PASSWORD)return;
 if(db.prepare('SELECT COUNT(*) AS n FROM users').get().n)return;
 const username=userId(process.env.INITIAL_ADMIN_USER||'ADMIN');
 const hashed=await hashPassword(process.env.INITIAL_ADMIN_PASSWORD);
 db.exec('BEGIN');
 try{
  if(!db.prepare('SELECT COUNT(*) AS n FROM users').get().n){
   db.prepare('INSERT INTO users(id,username,name,role,password,must_change) VALUES(?,?,?,?,?,1)').run(token(),username,'Administrator','administrator',hashed);
   log(db,'server-bootstrap','Created initial administrator; password change required');
  }
  db.exec('COMMIT');
 }catch(e){db.exec('ROLLBACK');throw e;}
}
